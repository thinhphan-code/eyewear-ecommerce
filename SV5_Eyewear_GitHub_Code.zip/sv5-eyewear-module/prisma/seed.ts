import { PrismaClient } from "@prisma/client";
import products from "../data/products.seed.json";

const prisma = new PrismaClient();

async function main() {
  for (const p of products) {
    await prisma.product.upsert({
      where: { slug: p.slug },
      update: {
        name: p.name, brand: p.brand, category: p.category,
        description: p.description, price: p.price, sourceUrl: p.sourceUrl,
        isPublished: false,
      },
      create: {
        slug: p.slug, name: p.name, brand: p.brand, category: p.category,
        description: p.description, price: p.price, sourceUrl: p.sourceUrl,
        isPublished: false,
      },
    });
  }
  console.log(`Seeded ${products.length} draft products. All are unpublished pending verification.`);
}

main().finally(async () => prisma.$disconnect());
