# SV5 – Eyewear E-commerce: Product Content, Reviews & Wishlist

Bộ mã nguồn độc lập cho phần việc SV5 (Tuần 1–2), dùng **Next.js App Router + TypeScript + Prisma + MySQL**.

## Có gì trong bộ mã nguồn?
- Prisma schema cho `Product`, `Review`, `WishlistItem`.
- API đánh giá sản phẩm: tạo đánh giá, kiểm tra dữ liệu, chặn đánh giá trùng theo người dùng/sản phẩm, tính điểm trung bình và phân trang.
- API Wishlist: thêm, xem, xóa sản phẩm; ràng buộc duy nhất để không thêm trùng.
- Trang chi tiết sản phẩm mẫu có form đánh giá và nút Wishlist.
- Dữ liệu seed 30 sản phẩm mẫu và CSV.
- 20 nội dung mô tả sản phẩm mẫu để nhóm biên tập/đối chiếu trước khi đăng.

## Yêu cầu
- Node.js 20+
- MySQL 8+
- Repository Next.js đã tạo bằng App Router.
- Đã có cơ chế đăng nhập. Module dùng `getCurrentUserId()` làm điểm nối; mặc định đọc `x-user-id` chỉ để chạy thử local. **Không dùng header này trong production**. Hãy thay bằng session từ Auth.js/NextAuth hoặc hệ thống đăng nhập của SV4.

## Cài đặt vào repository nhóm
1. Sao chép `prisma/schema.prisma`, `prisma/seed.ts`, `src/` và `data/` vào repository.
2. Cài thư viện:

```bash
npm install prisma @prisma/client zod
npm install -D tsx
npx prisma generate
```

3. Thêm vào `.env` (không commit file `.env`):

```env
DATABASE_URL="mysql://USER:PASSWORD@localhost:3306/eyewear_ecommerce"
```

4. Chạy migration và seed:

```bash
npx prisma migrate dev --name add_sv5_reviews_wishlist
npx prisma db seed
```

5. Chạy Next.js:

```bash
npm run dev
```

## Kết nối xác thực người dùng
Mở `src/lib/auth.ts`. Thay nội dung `getCurrentUserId()` bằng cách lấy ID từ session đăng nhập thật của nhóm. API review và wishlist đều yêu cầu người dùng đăng nhập. Header `x-user-id` chỉ là adapter demo local.

## API
- `GET /api/products/:id/reviews?page=1&limit=10`
- `POST /api/products/:id/reviews` – JSON `{ "rating": 5, "comment": "Sản phẩm tốt" }`
- `GET /api/wishlist`
- `POST /api/wishlist` – JSON `{ "productId": "..." }`
- `DELETE /api/wishlist/:productId`

## Quy tắc nghiệp vụ
- Rating là số nguyên từ 1 đến 5.
- Một tài khoản chỉ được đánh giá một lần cho một sản phẩm. Muốn sửa đánh giá thì bổ sung API cập nhật riêng.
- Wishlist không cho phép trùng sản phẩm trong cùng tài khoản.
- Review và Wishlist gắn với `userId`; cần đồng bộ tên trường với bảng User hiện có của SV1/SV4.
- `verifiedPurchase` mặc định `false`. Chỉ bật sau khi backend xác minh đơn hàng đã giao thành công; không tin giá trị do client gửi lên.

## Dữ liệu sản phẩm
`data/products.seed.json` có 30 bản ghi mẫu theo danh mục. Các thuộc tính kỹ thuật/giá chưa được xác minh được để `null` hoặc ghi chú rõ. Không tự động đăng bán trước khi nhóm đối chiếu nhà sản xuất/nhà bán lẻ và cập nhật giá, tồn kho, SKU, ảnh, URL nguồn chính thức.

## Nội dung 20 mô tả
Các nội dung trong `content/product-descriptions-20.md` là bản nháp mẫu. Thay các trường trong ngoặc vuông bằng thông số đã xác minh trước khi xuất bản. Không phải tư vấn y tế và không đưa ra cam kết điều trị/bảo vệ mắt tuyệt đối.

## Lưu ý tích hợp
- Dự án nhóm có thể đang dùng WooCommerce hoặc backend riêng. Nếu dùng WooCommerce làm nguồn dữ liệu chính, không tạo bảng Product thứ hai; thay Prisma Product query bằng adapter WooCommerce và giữ nguyên API contract.
- Không commit API keys, mật khẩu DB, `.env`.
- Trước khi nộp, chạy `npx tsc --noEmit`, test API với tài khoản demo và chụp ảnh minh chứng.
