import { headers } from "next/headers";

/**
 * ADAPTER DEMO: đọc x-user-id để tiện kiểm thử API local.
 * BẮT BUỘC thay bằng session/auth provider thật trước khi deploy.
 * Không cho phép client tự chọn userId trong body.
 */
export async function getCurrentUserId(): Promise<string | null> {
  if (process.env.NODE_ENV === "production") {
    // Fail closed: production không chấp nhận header giả lập.
    return null;
  }
  const h = await headers();
  return h.get("x-user-id");
}
