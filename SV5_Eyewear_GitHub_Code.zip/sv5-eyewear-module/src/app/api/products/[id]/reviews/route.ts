import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUserId } from "@/lib/auth";
import { createReviewSchema, positiveInt } from "@/lib/validation";

type Context = { params: Promise<{ id: string }> };

export async function GET(request: NextRequest, context: Context) {
  const { id: productId } = await context.params;
  const page = positiveInt(request.nextUrl.searchParams.get("page"), 1, 100000);
  const limit = positiveInt(request.nextUrl.searchParams.get("limit"), 10, 50);

  const product = await prisma.product.findUnique({
    where: { id: productId },
    select: { id: true },
  });
  if (!product) return NextResponse.json({ error: "Không tìm thấy sản phẩm." }, { status: 404 });

  const where = { productId, isVisible: true };
  const [items, total, aggregate] = await Promise.all([
    prisma.review.findMany({
      where, orderBy: { createdAt: "desc" }, skip: (page - 1) * limit, take: limit,
      select: { id: true, rating: true, comment: true, verifiedPurchase: true, createdAt: true },
    }),
    prisma.review.count({ where }),
    prisma.review.aggregate({ where, _avg: { rating: true }, _count: { rating: true } }),
  ]);

  return NextResponse.json({
    items,
    pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
    summary: {
      averageRating: aggregate._avg.rating ? Number(aggregate._avg.rating.toFixed(2)) : 0,
      reviewCount: aggregate._count.rating,
    },
  });
}

export async function POST(request: NextRequest, context: Context) {
  const userId = await getCurrentUserId();
  if (!userId) return NextResponse.json({ error: "Vui lòng đăng nhập để đánh giá." }, { status: 401 });

  const { id: productId } = await context.params;
  const body = await request.json().catch(() => null);
  const parsed = createReviewSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Dữ liệu không hợp lệ.", details: parsed.error.flatten() }, { status: 400 });
  }

  const product = await prisma.product.findUnique({ where: { id: productId }, select: { id: true } });
  if (!product) return NextResponse.json({ error: "Không tìm thấy sản phẩm." }, { status: 404 });

  try {
    const review = await prisma.review.create({
      data: {
        productId, userId, rating: parsed.data.rating,
        comment: parsed.data.comment,
        // Chỉ backend có thể xác minh đơn hàng; mặc định false.
        verifiedPurchase: false,
      },
      select: { id: true, rating: true, comment: true, createdAt: true },
    });
    return NextResponse.json({ message: "Đã gửi đánh giá.", review }, { status: 201 });
  } catch (error: unknown) {
    // Unique constraint [productId,userId] chặn đánh giá trùng.
    if (typeof error === "object" && error !== null && "code" in error && error.code === "P2002") {
      return NextResponse.json({ error: "Bạn đã đánh giá sản phẩm này rồi." }, { status: 409 });
    }
    return NextResponse.json({ error: "Không thể lưu đánh giá lúc này." }, { status: 500 });
  }
}
