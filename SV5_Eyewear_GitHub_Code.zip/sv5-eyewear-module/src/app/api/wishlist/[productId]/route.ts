import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUserId } from "@/lib/auth";

type Context = { params: Promise<{ productId: string }> };

export async function DELETE(_request: Request, context: Context) {
  const userId = await getCurrentUserId();
  if (!userId) return NextResponse.json({ error: "Vui lòng đăng nhập." }, { status: 401 });

  const { productId } = await context.params;
  const result = await prisma.wishlistItem.deleteMany({ where: { userId, productId } });
  if (result.count === 0) return NextResponse.json({ error: "Sản phẩm không có trong Wishlist." }, { status: 404 });
  return NextResponse.json({ message: "Đã xóa khỏi Wishlist." });
}
