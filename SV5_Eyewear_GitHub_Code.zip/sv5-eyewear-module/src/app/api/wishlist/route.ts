import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUserId } from "@/lib/auth";
import { addWishlistSchema } from "@/lib/validation";

export async function GET() {
  const userId = await getCurrentUserId();
  if (!userId) return NextResponse.json({ error: "Vui lòng đăng nhập." }, { status: 401 });

  const items = await prisma.wishlistItem.findMany({
    where: { userId },
    orderBy: { createdAt: "desc" },
    include: { product: true },
  });
  return NextResponse.json({ items });
}

export async function POST(request: NextRequest) {
  const userId = await getCurrentUserId();
  if (!userId) return NextResponse.json({ error: "Vui lòng đăng nhập." }, { status: 401 });

  const body = await request.json().catch(() => null);
  const parsed = addWishlistSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "productId không hợp lệ." }, { status: 400 });

  const product = await prisma.product.findUnique({ where: { id: parsed.data.productId } });
  if (!product) return NextResponse.json({ error: "Không tìm thấy sản phẩm." }, { status: 404 });

  const item = await prisma.wishlistItem.upsert({
    where: { userId_productId: { userId, productId: product.id } },
    create: { userId, productId: product.id },
    update: {},
    include: { product: true },
  });
  return NextResponse.json({ message: "Đã thêm vào yêu thích.", item }, { status: 200 });
}
