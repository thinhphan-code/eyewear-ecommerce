"use client";

import { useEffect, useState } from "react";

type Review = { id: string; rating: number; comment: string | null; createdAt: string };
type ReviewResponse = {
  items: Review[];
  pagination: { page: number; totalPages: number; total: number };
  summary: { averageRating: number; reviewCount: number };
};

export function ReviewWishlist({ productId }: { productId: string }) {
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [message, setMessage] = useState("");
  const [reviews, setReviews] = useState<ReviewResponse | null>(null);
  const [page, setPage] = useState(1);

  async function loadReviews(nextPage = page) {
    const res = await fetch(`/api/products/${productId}/reviews?page=${nextPage}&limit=5`);
    if (res.ok) setReviews(await res.json());
  }

  useEffect(() => { void loadReviews(1); }, [productId]);

  async function submitReview(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setMessage("");
    const res = await fetch(`/api/products/${productId}/reviews`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ rating, comment }),
    });
    const data = await res.json();
    setMessage(data.message ?? data.error ?? "Có lỗi xảy ra.");
    if (res.ok) { setComment(""); setPage(1); await loadReviews(1); }
  }

  async function addWishlist() {
    const res = await fetch("/api/wishlist", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ productId }),
    });
    const data = await res.json();
    setMessage(data.message ?? data.error ?? "Có lỗi xảy ra.");
  }

  return (
    <section style={{ marginTop: 32 }}>
      <button onClick={addWishlist}>♡ Thêm vào Wishlist</button>
      <h2>Đánh giá sản phẩm</h2>
      <form onSubmit={submitReview}>
        <label>Chọn số sao:{" "}
          <select value={rating} onChange={e => setRating(Number(e.target.value))}>
            {[5,4,3,2,1].map(n => <option key={n} value={n}>{n} sao</option>)}
          </select>
        </label>
        <p><textarea value={comment} onChange={e => setComment(e.target.value)} maxLength={1500}
          placeholder="Chia sẻ trải nghiệm của bạn..." rows={4} /></p>
        <button type="submit">Gửi đánh giá</button>
      </form>
      {message && <p role="status">{message}</p>}
      <h3>Nhận xét ({reviews?.summary.reviewCount ?? 0})</h3>
      {reviews?.items.map(item => (
        <article key={item.id} style={{ borderTop: "1px solid #ddd", padding: "12px 0" }}>
          <strong>{"★".repeat(item.rating)}{"☆".repeat(5-item.rating)}</strong>
          <p>{item.comment || "Không có nhận xét."}</p>
          <small>{new Date(item.createdAt).toLocaleDateString("vi-VN")}</small>
        </article>
      ))}
      {reviews && reviews.pagination.totalPages > 1 && (
        <div>
          <button disabled={page <= 1} onClick={() => { const p = page - 1; setPage(p); void loadReviews(p); }}>Trước</button>
          <span> Trang {page}/{reviews.pagination.totalPages} </span>
          <button disabled={page >= reviews.pagination.totalPages} onClick={() => { const p = page + 1; setPage(p); void loadReviews(p); }}>Sau</button>
        </div>
      )}
    </section>
  );
}
