import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { ReviewWishlist } from "./review-wishlist";

type Props = { params: Promise<{ slug: string }> };

export default async function ProductPage({ params }: Props) {
  const { slug } = await params;
  const product = await prisma.product.findUnique({
    where: { slug, isPublished: true },
    select: { id: true, name: true, brand: true, category: true, description: true, price: true, imageUrl: true },
  });
  if (!product) notFound();

  const aggregate = await prisma.review.aggregate({
    where: { productId: product.id, isVisible: true },
    _avg: { rating: true }, _count: { rating: true },
  });

  return (
    <main style={{ maxWidth: 900, margin: "40px auto", padding: 24, fontFamily: "Arial, sans-serif" }}>
      <p>{product.category}</p>
      <h1>{product.name}</h1>
      {product.brand && <p>Thương hiệu: {product.brand}</p>}
      {product.imageUrl && <img src={product.imageUrl} alt={product.name} style={{ maxWidth: 320, height: "auto" }} />}
      <p>{product.description}</p>
      <p>{product.price ? `${Number(product.price).toLocaleString("vi-VN")} ${"₫"}` : "Giá: liên hệ/cập nhật"}</p>
      <p>Đánh giá: {aggregate._avg.rating?.toFixed(1) ?? "Chưa có"} / 5 ({aggregate._count.rating} lượt)</p>
      <ReviewWishlist productId={product.id} />
    </main>
  );
}
