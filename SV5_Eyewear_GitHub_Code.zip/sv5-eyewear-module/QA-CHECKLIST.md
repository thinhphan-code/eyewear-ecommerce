# QA checklist – SV5

## Reviews
- [ ] GET reviews của sản phẩm tồn tại trả danh sách, phân trang và summary.
- [ ] GET sản phẩm không tồn tại trả 404.
- [ ] POST khi chưa đăng nhập trả 401.
- [ ] POST rating = 0, 6, 2.5 hoặc chuỗi trả 400.
- [ ] POST rating 1–5 hợp lệ trả 201.
- [ ] Gửi review lần hai cùng user/product trả 409.
- [ ] Nội dung quá 1500 ký tự trả 400.
- [ ] Review bị ẩn (`isVisible=false`) không xuất hiện trong danh sách/điểm trung bình.

## Wishlist
- [ ] GET khi chưa đăng nhập trả 401.
- [ ] POST productId không tồn tại trả 404.
- [ ] POST hợp lệ trả item.
- [ ] POST cùng sản phẩm nhiều lần không tạo bản ghi trùng.
- [ ] DELETE chỉ xóa wishlist thuộc user hiện tại.
- [ ] DELETE item không tồn tại trả 404.

## Bảo mật và tích hợp
- [ ] Thay `getCurrentUserId()` bằng session đăng nhập thật.
- [ ] Không commit `.env` hoặc API key.
- [ ] Chỉ backend xác minh `verifiedPurchase`.
- [ ] Thêm rate limit tại middleware/API gateway trước khi deploy.
- [ ] Rà soát quyền truy cập và CSRF theo kiến trúc xác thực thực tế.
